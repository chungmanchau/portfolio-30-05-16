$(".toggle-btn").on("click", function() {
	$(".menu").toggleClass("active");
});